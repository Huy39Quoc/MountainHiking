/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Presentation;

/**
 *
 * @author tranhuy
 */
public class Menu {
    public static void printMenu(String menu){
        menu = menu.replace("|", "\n");
        System.out.println(menu);
    }
}
