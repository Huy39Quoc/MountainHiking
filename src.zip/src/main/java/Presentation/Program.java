/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Presentation;

/**
 *
 * @author tranhuy
 */
import Core.Interfaces.IMountainDAO;
import Core.Interfaces.IStudentDAO;
import Management.MountainDAO;
import Management.StudentDAO;
import Utilities.DataInput;
import java.util.stream.Collectors;
import Core.Interfaces.FileManager;
public class Program {
    public static void main(String[] args) throws Exception {
        String mountain = "MountainList.csv";
        String student = "Student.csv";
        IStudentDAO StudentDAO = new StudentDAO(student, mountain);
        do{
        Menu.printMenu("1. New Registration.|2. Update Registration Information.|3. Display Registered List.|4. Delete Registration Information."
                + "|5. Search Participants by Name.|6. Filter Data by Campus.|7. Statistics of Registration Numbers by Location."
                + "|8. Save Data to File.|9. Exit the Program.|");
        
        int number = DataInput.getInt("Please enter your number: ");
        switch(number){
            case 1 ->{
                StudentDAO.Register();
            }
            
            case 2 ->{
                StudentDAO.Update();
            }
            
            case 3 ->{
                StudentDAO.Display();
            }
            
            case 4 ->{
                StudentDAO.Delete();
            }
            
            case 5 ->{
                StudentDAO.SearchByName();
            }
            
            case 6 ->{
                StudentDAO.Campus();
            }
            
            case 7 ->{
                StudentDAO.Statistics();
            }
            
            case 8 ->{
                StudentDAO.SaveFile();
            }
            
            case 9 ->{
                System.out.println("Do you want to save the changes before exiting? (Y/N)");
                String input = DataInput.getString();
                if(input.equalsIgnoreCase("Y")){
                   System.exit(0);
                }
            }
            
            default ->{
                System.out.println("Please enter number from 1-9.");
            }
        }
        }while(true);
        
    }
}
