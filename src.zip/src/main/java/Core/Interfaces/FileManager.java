/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Core.Interfaces;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author tranhuy
 */
public class FileManager {
    private String fileName;
    
    public FileManager(String fileName){
        this.fileName = fileName;
    }
    
    public List<String> ReadFromFile() throws Exception{
        return Files.readAllLines(new File(fileName).toPath(), Charset.forName("utf-8")).stream().skip(1).collect(Collectors.toList());
    }
    
    public void SaveToFile(String data) throws Exception{
        System.out.println(data);
        String firstLine = Files.readAllLines(new File(fileName).toPath(), Charset.forName("utf-8")).stream().findFirst().orElse(null);
        Files.writeString(new File(fileName).toPath(), firstLine + "\n" + data, Charset.forName("utf-8"));
        System.out.println("Save successfully.");
    }
}
