/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Core.Interfaces;

import Core.Entities.Mountain;
import java.util.List;

/**
 *
 * @author tranhuy
 */
public interface IMountainDAO {
    List<Mountain> getMountainSort() throws Exception;
    void displayMountain() throws Exception;
}
