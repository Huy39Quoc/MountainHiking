/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Core.Interfaces;

/**
 *
 * @author tranhuy
 */
import Core.Entities.Student;
import java.util.List;
public interface IStudentDAO {
    List<Student> getStudent() throws Exception;
    void Register() throws Exception;
    void Update() throws Exception;
    void Display() throws Exception;
    void Delete() throws Exception;
    void SearchByName() throws Exception;
    void Campus() throws Exception;
    void Statistics() throws Exception;
    void SaveFile() throws Exception;
}
