/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Core.Entities;

import java.text.DecimalFormat;

/**
 *
 * @author tranhuy
 */
public class Student {
    String ID, Name, Phone, Email, Peak;
    int Fee;
    
    public Student(String ID, String Name, String Phone, String email, String Peak, int Fee){
        this.ID = ID;
        this.Name = Name;
        this.Phone = Phone;
        this.Email = email;
        this.Peak = Peak;
        this.Fee = Fee;
    }

    public String getID() {
        return ID;
    }

    public String getName() {
        return Name;
    }

    public String getPhone() {
        return Phone;
    }
    
    public String getEmail(){
        return Email;
    }

    public String getPeak() {
        if(Peak.length() == 1){
            return "MT0" + Peak;
        }else{
            return "MT" + Peak;
        }
    }

    public String getFee() {
        return new DecimalFormat("#,###").format(Fee);
    }

    public void setID(String ID) {
        this.ID = ID;
    }
    public void setName(String Name) {
        this.Name = Name;
    }

    public void setPhone(String Phone) {
        this.Phone = Phone;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public void setPeak(String Peak) {
        this.Peak = Peak;
    }
    
    @Override
    public String toString(){
        return String.format("%s, %s, %s, %s, %s, %s", getID(),getName(), getPhone(), getEmail(), getPeak().contains("MT0") ? getPeak().replace("MT0", "") : getPeak().contains("MT") ? getPeak().replace("MT", "") : getPeak(), getFee().replace(".", ""));
    }
}
