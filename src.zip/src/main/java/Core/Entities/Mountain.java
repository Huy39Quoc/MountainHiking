/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Core.Entities;

/**
 *
 * @author tranhuy
 */
public class Mountain {
    private String code, mountain, province, description;
    
    public Mountain(String code, String mountain, String province, String description){
        this.code = code;
        this.mountain = mountain;
        this.province = province;
        this.description = description;
    }

    public String getCode() {
        if(code.length() == 1){
            return "MT0" + code;
        }else{
            return "MT" + code;
        }
    }

    public String getMountain() {
        return mountain;
    }

    public String getProvince() {
        return province;
    }

    public String getDescription() {
        if(description.equals(" ")){
            return "\n No Description";
        }else{
            return description;
        }
    }
    
    
}
