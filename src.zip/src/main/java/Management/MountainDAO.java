/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Management;

import Core.Entities.Mountain;
import Core.Interfaces.FileManager;
import Core.Interfaces.IMountainDAO;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author tranhuy
 */
public class MountainDAO implements IMountainDAO {
    final List<Mountain> getMountain = new ArrayList();
    private String fileName;
    private FileManager fileManager;
    
    public MountainDAO(String fileName) throws Exception{
        this.fileName = fileName;
        System.out.println(fileName);
        fileManager = new FileManager(fileName);
        LoadFile();
    }
    
    public void LoadFile() throws Exception{
        try{
            getMountain.clear();
            String code, mountain, province, description;
            List<String> getFile = fileManager.ReadFromFile();
            if(!getFile.isEmpty()){
                for(String info: getFile){
                    List<String> get = Arrays.asList(info.split(", "));
                    code = get.get(0);
                    mountain = get.get(1);
                    province = get.get(2);
                    description = get.get(3);
                    getMountain.add(new Mountain(code, mountain, province, description));
                }
            }
        }catch(Exception e){
           System.out.println(">>Error: " + e.getMessage());
        }
    }
    
    public List<Mountain> getMountainSort() throws Exception{
        Collections.sort(getMountain, (m1, m2) -> m1.getCode().compareTo(m2.getCode()));
        return getMountain;
    }
    
    public void displayMountain() throws Exception{
        System.out.println(getMountain.size());
        System.out.println(String.join(",", Collections.nCopies(80, "-")).replace(",", ""));
        if(!getMountain.isEmpty()){
        for(Mountain get: getMountain){
            System.out.printf("""
                   Code:      %s
                   Mountain:  %s
                   Province:  %s
                   Description:
                   %s
                   """, get.getCode(), get.getMountain(), get.getProvince(), get.getDescription());
            System.out.println(String.join(",", Collections.nCopies(80, "-")).replace(",", ""));
         }
        }else{
            System.out.println("List is empty.");
        } 
    }   
}
