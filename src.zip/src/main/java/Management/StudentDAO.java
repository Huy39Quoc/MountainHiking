/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Management;

/**
 *
 * @author tranhuy
 */
import Core.Entities.Mountain;
import Core.Entities.Student;
import Core.Interfaces.IStudentDAO;
import java.util.ArrayList;
import java.util.List;
import Utilities.DataInput;
import Utilities.Validation;
import java.util.stream.Collectors;
import Core.Interfaces.FileManager;
import java.util.Arrays;
import Core.Interfaces.IMountainDAO;
import java.text.DecimalFormat;
import java.util.Collections;
public class StudentDAO implements IStudentDAO{
    private final List<Student> getStudentList = new ArrayList();
    private final FileManager fileManagerStudent;
    IMountainDAO MountainDAO;
    public StudentDAO(String Student, String Mountain) throws Exception{
        fileManagerStudent = new FileManager(Student);
        MountainDAO = new MountainDAO(Mountain);
        LoadFile();
    }
    
    public void LoadFile() throws Exception{
        try{
            getStudentList.clear();
            String id, name, phone, email, mountain, fee;
            List<String> getFile = fileManagerStudent.ReadFromFile();
            if(!getFile.isEmpty()){
                for(String info: getFile){
                    List<String> get = Arrays.asList(info.split(", "));
                    id = get.get(0);
                    name = get.get(1);
                    phone = get.get(2);
                    email = get.get(3);
                    mountain = get.get(4);
                    fee = get.get(5);
                    getStudentList.add(new Student(id, name, phone, email, mountain, Integer.parseInt(fee))); 
                }
            }else{
                System.out.println("List is empty.");
            }
        }catch(Exception e){
            System.out.println(">>Error: " + e.getMessage());
        }
    }
    
    public List<Student> getStudent() throws Exception{
        Collections.sort(getStudentList, (s1, s2) -> s1.getID().compareTo(s2.getID()));
        return getStudentList;
    }
    public void Register() throws Exception{
         String id = ID();
         if(id.equals("")){
             System.out.println("Your id is not unique or you just quit");
             return;
         }
         
         String name = Name();
         if(name.equals("")){
             return;
         }
         
         String phone = Phone();
         if(phone.equals("")){
             return;
         }
         
         String email = Email();
         if(email.equals("")){
             return;
         }
         
         String code = Peak();
         if(code.equals("")){
             return;
         }
         
         int money = 6000000;
         if((phone.charAt(0) + "" + phone.charAt(1)).equals("09") || (phone.charAt(0) + "" + phone.charAt(1)).equals("03") || (phone.charAt(0) + "" + phone.charAt(1)).equals("08")){
             money = money - (money * 35/100);
         }
         getStudentList.add(new Student(id, name, phone, email, code, money));
         System.out.println("Register successfully");
    }
    
    public void Update() throws Exception{
        String id = DataInput.getString("Please enter the id that you want to update: ");
        Student find = getStudentList.stream().filter(item -> item.getID().equalsIgnoreCase(id)).findAny().orElse(null);
        if(find == null){
            System.out.println("Code is not found");
        }else{
          String name = Name();
         if(!name.equals("")){
             find.setName(name);
         }
         
         String phone = Phone();
         if(!phone.equals("")){
             find.setPhone(phone);
         }
         
         String email = Email();
         if(!email.equals("")){
             find.setEmail(email);
         }
         
         String code = Peak();
         if(!code.equals("")){
             find.setPeak(code);
         }
        }
    }
    
    public void Display() throws Exception{
        if(getStudentList.isEmpty()){
            System.out.println("List is empty.");
        }else{
            System.out.println(String.join(",", Collections.nCopies(80, "-")).replace(",", ""));
            System.out.printf("%-13s|%-18s|%-15s|%-11s|%s\n", "Student ID", "Name", "Phone", "Peak Code", "Fee");
            System.out.println(String.join(",", Collections.nCopies(80, "-")).replace(",", ""));
            for(Student student: getStudentList){
                System.out.printf("%-13s|%-18s|%-15s|%-11s|%s\n", student.getID(), student.getName(), student.getPhone(), student.getPeak(), student.getFee());
            }
            System.out.println(String.join(",", Collections.nCopies(80, "-")).replace(",", ""));
        }
    }
    
    public void Delete() throws Exception{
        String id = DataInput.getString("Please enter the id that you want to update: ");
        Student find = getStudentList.stream().filter(item -> item.getID().equalsIgnoreCase(id)).findAny().orElse(null);
        if(find == null){
            System.out.println("Code is not found.");
        }else{
            System.out.printf("""
                               -----------------------------------------------------
                               Student ID: %s
                               Name :      %s
                               Phone :     %s
                               Mountain :  %s
                               Fee :       %s
                               -----------------------------------------------------
                               """, find.getID(), find.getName(), find.getPhone(), find.getPeak(), find.getFee());
            System.out.println("");
            String answer = DataInput.getString("Are you sure you want to delete this registration? (Y/N): ");
            if(answer.equalsIgnoreCase("Y")){
                getStudentList.remove(getStudentList.indexOf(find));
            }  
        }
    }
    
    public void SearchByName() throws Exception{
        String name = DataInput.getString("Please enter the name to search: ");
        List<Student> find = getStudentList.stream().filter(item -> item.getName().contains(name)).collect(Collectors.toList());
        if(find == null){
            System.out.println("Name is not found.");
        }else{
            System.out.println(String.join(",", Collections.nCopies(80, "-")).replace(",", ""));
            System.out.printf("%-13s|%-18s|%-15s|%-11s|%s\n", "Student ID", "Name", "Phone", "Peak Code", "Fee");
            System.out.println(String.join(",", Collections.nCopies(80, "-")).replace(",", ""));
            for(Student student: find){
                System.out.printf("%-13s|%-18s|%-15s|%-11s|%s\n", student.getID(), student.getName(), student.getPhone(), student.getPeak(), student.getFee());
            }
            System.out.println(String.join(",", Collections.nCopies(80, "-")).replace(",", ""));
        }
    }
    
    public void Campus() throws Exception{
        String id = DataInput.getString("Please enter campus code: ");
        List<Student> find = getStudentList.stream().filter(item -> (item.getID().charAt(0) + "" + item.getID().charAt(1)).equalsIgnoreCase(id)).collect(Collectors.toList());
        if(find == null){
            System.out.println("Code is not found.");
        }else{
            System.out.printf("Registered Students Under %s Campus(%s):\n", 
                                 id.equalsIgnoreCase("CE") ? "Can Tho" :
                                 id.equalsIgnoreCase("DE") ? "Da Nang" :
                                 id.equalsIgnoreCase("HE") ? "Ha Noi" :
                                 id.equalsIgnoreCase("SE") ? "Ho Chi Minh" :
                                 id.equalsIgnoreCase("QE") ? "Quy Nhon" : "Not campus code.", id);

            System.out.println(String.join(",", Collections.nCopies(80, "-")).replace(",", ""));
            System.out.printf("%-13s|%-18s|%-15s|%-11s|%s\n", "Student ID", "Name", "Phone", "Peak Code", "Fee");
            System.out.println(String.join(",", Collections.nCopies(80, "-")).replace(",", ""));
            for(Student student: find){
                System.out.printf("%-13s|%-18s|%-15s|%-11s|%s\n", student.getID(), student.getName(), student.getPhone(), student.getPeak(), student.getFee());
            }
            System.out.println(String.join(",", Collections.nCopies(80, "-")).replace(",", ""));
        }
    }
    
    
    public void Statistics() throws Exception{
        List<String> MT = getStudentList.stream().map(item -> item.getPeak()).distinct().collect(Collectors.toList());
        if(!MT.isEmpty()){
            System.out.println("""
                               -----------------------------------------------------------------
                               Peak Name     | Number of Participants     |  Total Cost
                               -----------------------------------------------------------------
                               """);
        for(String mt: MT){
            int count = (int) getStudentList.stream().filter(item -> item.getPeak().equalsIgnoreCase(mt)).count();
            int fee = getStudentList.stream().filter(item -> item.getPeak().equalsIgnoreCase(mt)).mapToInt(item -> Integer.valueOf(item.getFee().replace(".", ""))).sum();
            System.out.printf("""
                               %s            | %d                         | %d
                               """, mt, count, fee);
          }
            System.out.println("-----------------------------------------------------------------");
        }else{
            System.out.println("List is empty.");
        }
    }
    
    public void SaveFile() throws Exception{
        fileManagerStudent.SaveToFile(String.join("\n", getStudentList.stream().map(String::valueOf).collect(Collectors.toList())));
    }
    
    public String ID(){
        String id = "";
        while(true){
              id = DataInput.getString("Please enter the id(SE|HE|DE|QE|CE with 6 ): ");
            if(Validation.checkFormat(id, "^(SE|HE|DE|QE|CE)\\d{6}$")){
                break;
            }else{
                System.out.println("Your enter id is incorrect, enter 1 to continue, or else is quit");
                if(!DataInput.getString("Please enter your choice: ").equals("1")){
                    return "";
                }
            }
        }
        String Sid = id;
        List<Student> unique = getStudentList.stream().filter(item -> item.getID().equalsIgnoreCase(Sid)).collect(Collectors.toList());
        if(!unique.isEmpty()){
            return "";
        }else{
            return id;
        }
    }
    
    public String Name(){
        String name = "";
        while(true){
            name = DataInput.getString("Please enter the name: ");
            if(Validation.checkNameLength(name)){
                return name;
            }else{
                System.out.println("Make sure your name is between 2 and 20. Enter 1 to continue, or else is quit.");
                name = DataInput.getString("Please enter your choice: ");
                if(!name.equals("1")){
                    return "";
                }
            }
        }
    }
    
    public String Phone(){
        String phone = "";
        while(true){
            phone = DataInput.getString("Please enter the phone number: ");
            if(Validation.checkFormat(phone, "^0(3[0-9]|8[0-9]|9[0-9])\\d{7}$")){
                return phone;
            }else{
                System.out.println("Please enter a 10-digit Vietnamese phone number starting with 03, 08, or 09 (e.g., 0981234567)");
                System.out.println("Enter 1 to continue, or else is quit.");
                phone = DataInput.getString("Please enter your choice: ");
                if(!phone.equals("1")){
                    return "";
                }
            }
        }
    }
    
    public String Email(){
        String email = "";
        while(true){
            email = DataInput.getString("Please enter email: ");
            if(Validation.checkFormat(email, "^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$")){
                return email;
            }else{
                System.out.println("Please following the mail format.");
                System.out.println("Enter 1 to continue, or else is quit.");
                email = DataInput.getString("Please enter your choice: ");
                if(!email.equals("1")){
                    return "";
                }
            }
        }
    }
    
    public String Peak() throws Exception{
        String peak;
        while(true){
            MountainDAO.displayMountain();
            peak = DataInput.getString("Please enter code(Mountain Peak code): ");
            final String take = peak;
            List<Mountain> get = MountainDAO.getMountainSort().stream().filter(item -> item.getCode().equalsIgnoreCase(take)).collect(Collectors.toList());
            if(!get.isEmpty()){
                return peak.toUpperCase();
            }else{
                System.out.println("Please enter code in list.");
                System.out.println("Enter 1 to continue, or else is quit.");
                peak = DataInput.getString("Please enter your choice: ");
                if(!peak.equals("1")){
                    return "";
                }
            }
        }
    }
}
