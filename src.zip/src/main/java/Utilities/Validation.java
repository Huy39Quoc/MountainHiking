/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilities;

/**
 *
 * @author tranhuy
 */
public class Validation {
    public static boolean isInteger(String item) throws Exception{
        try{
            int num = Integer.parseInt(item);
            return true;
        }catch(Exception e){
            System.out.print("Your input is not integer. Please try again, or enter non-numeric to quit: ");
            return false;
        }
    }
    
    public static boolean checkID(String item){
       return item.matches("^(SE|HE|DE|QE|CE)\\d{6}$");
    }
    
    public static boolean checkFormat(String item, String format){
        return item.matches(format);
    }
    
    public static boolean checkNameLength(String item){
        return item.length() >= 2 && item.length() <= 20;
    }
}
