/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilities;

/**
 *
 * @author tranhuy
 */
import java.util.Scanner;
public class DataInput {
    public static int getInt(String message) throws Exception{
        System.out.print(message);
        boolean stop = false;
        while(true){
            String input = getString();
            if(Validation.isInteger(input)){
                return Integer.parseInt(input);
            }else{
                if(stop == false){
                    stop = true;
                }else{
                    return 9;
                }
            }
        }
    }
    
    public static String getString(String message){
        System.out.print(message);
        return getString();
    }
    
    public static String getString(){
        return new Scanner(System.in).nextLine();
    }
}
